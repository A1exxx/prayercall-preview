<?php
/**
 * Plugin Name: Prayer Call — новый вид
 * Description: Показывает новый вид сайта (главная, разделы, статьи на EN и RU) из готовых страниц в папке static/. Записи, вход, регистрация и скачивание остаются за WordPress. Отключить плагин — вернётся прежний вид.
 * Version: 1.0.0
 * Author: Prayer Call
 */

if (!defined('ABSPATH')) {
	exit;
}

define('PCNL_DIR', __DIR__ . '/static');

// Параметры, с которыми страница всё равно показывается в новом виде (метки рекламы и т. п.).
// Любой другой параметр (например, скачивание ?sdm_process_download) уходит в WordPress как раньше.
function pcnl_query_is_plain() {
	foreach (array_keys($_GET) as $key) {
		if (!preg_match('/^(utm_\w+|fbclid|gclid|yclid|nc)$/', $key)) {
			return false;
		}
	}
	return true;
}

function pcnl_serve() {
	if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true) || !pcnl_query_is_plain()) {
		return;
	}
	$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
	$home = rtrim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
	if ($home !== '' && strpos($path, $home) === 0) {
		$path = substr($path, strlen($home));
	}
	$rel = trim($path, '/');
	if (strpos($rel, '..') !== false || preg_match('#^(wp-|assets/)#', $rel)) {
		return;
	}
	$file = PCNL_DIR . ($rel === '' ? '' : '/' . $rel) . '/index.html';
	if (!is_file($file)) {
		return;
	}
	if ($rel !== '' && substr($path, -1) !== '/') {
		wp_redirect(home_url('/' . $rel . '/'), 301);
		exit;
	}
	$base = plugin_dir_url(__FILE__) . 'static/';
	$html = file_get_contents($file);
	$html = preg_replace('#\b(href|src|poster)="(?:\.\./)*assets/#', '$1="' . $base . 'assets/', $html);
	status_header(200);
	header('Content-Type: text/html; charset=utf-8');
	header('X-LiteSpeed-Cache-Control: no-cache');
	header('Cache-Control: no-cache');
	echo $html;
	exit;
}
add_action('plugins_loaded', 'pcnl_serve', -1000);

function pcnl_purge_cache() {
	do_action('litespeed_purge_all');
}
register_activation_hook(__FILE__, 'pcnl_purge_cache');
register_deactivation_hook(__FILE__, 'pcnl_purge_cache');
