<?php
/**
 * Plugin Name: Prayer Call — новый вид
 * Description: Показывает новый вид сайта (главная, разделы, статьи на EN и RU) из готовых страниц в папке static/. Новые записи из рубрик «Сайт RU — …» и «Site EN — …» сами появляются в нужном разделе. Вход, регистрация и скачивание остаются за WordPress. Отключить плагин — вернётся прежний вид.
 * Version: 1.1.0
 * Author: Prayer Call
 */

if (!defined('ABSPATH')) {
	exit;
}

define('PCNL_DIR', __DIR__ . '/static');

// Параметры, с которыми страница всё равно показывается в новом виде (метки рекламы и т. п.).
// Любой другой параметр (например, скачивание ?sdm_process_download) уходит в WordPress как раньше.
function pcnl_query_is_plain() {
	foreach (array_keys($_GET) as $key) {
		if (!preg_match('/^(utm_\w+|fbclid|gclid|yclid|nc)$/', $key)) {
			return false;
		}
	}
	return true;
}

// Путь запроса без адреса сайта и без косых по краям; null — запрос не для нового вида.
function pcnl_rel_path() {
	if (PHP_SAPI === 'cli' || !isset($_SERVER['REQUEST_URI'])) {
		return null;
	}
	if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true) || !pcnl_query_is_plain()) {
		return null;
	}
	$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
	$home = rtrim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
	if ($home !== '' && strpos($path, $home) === 0) {
		$path = substr($path, strlen($home));
	}
	$rel = trim($path, '/');
	if (strpos($rel, '..') !== false || preg_match('#^(wp-|assets/)#', $rel)) {
		return null;
	}
	return $rel;
}

function pcnl_output($html) {
	$base = plugin_dir_url(__FILE__) . 'static/';
	$html = preg_replace('#\b(href|src|poster)="(?:\.\./)*assets/#', '$1="' . $base . 'assets/', $html);
	status_header(200);
	header('Content-Type: text/html; charset=utf-8');
	header('X-LiteSpeed-Cache-Control: no-cache');
	header('Cache-Control: no-cache');
	echo $html;
	exit;
}

function pcnl_serve() {
	$rel = pcnl_rel_path();
	if ($rel === null) {
		return;
	}
	$file = PCNL_DIR . ($rel === '' ? '' : '/' . $rel) . '/index.html';
	if (!is_file($file)) {
		return;
	}
	$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
	if ($rel !== '' && substr($path, -1) !== '/') {
		wp_redirect(home_url('/' . $rel . '/'), 301);
		exit;
	}
	$html = file_get_contents($file);
	if (preg_match('#^(?:(ru)/)?(molitva|resursy|post-daniila)$#', $rel, $m)) {
		$html = pcnl_add_posts_to_list($html, $m[1] === 'ru' ? 'ru' : 'en', $m[2]);
	}
	pcnl_output($html);
}
// Разделы со списком новых записей ждут, пока WordPress загрузит рубрики; остальные страницы отдаются сразу.
add_action('plugins_loaded', function () {
	$rel = pcnl_rel_path();
	if ($rel !== null && !preg_match('#^(?:ru/)?(molitva|resursy|post-daniila)$#', $rel)) {
		pcnl_serve();
	}
}, -1000);
add_action('wp_loaded', 'pcnl_serve', -1000);

function pcnl_purge_cache() {
	do_action('litespeed_purge_all');
}
register_activation_hook(__FILE__, 'pcnl_activate');
register_deactivation_hook(__FILE__, 'pcnl_purge_cache');

/* ---------- Новые записи в новом виде ----------
 * Запись в рубрике pc-<язык>-<раздел> показывается в разделе <раздел> на языке <язык>:
 * английская по адресу /<ярлык>/, русская — /ru/<ярлык>/. Страница собирается по образцу готовой статьи того же раздела.
 */
const PCNL_SECTIONS = [
	'molitva' => ['ru' => 'Молитва', 'en' => 'Prayer', 'sample' => 'lichnoe-vremya-s-bogom'],
	'resursy' => ['ru' => 'Ресурсы', 'en' => 'Resources', 'sample' => 'molitvennoe-hozhdenie'],
	'post-daniila' => ['ru' => 'Пост Даниила', 'en' => 'Daniel Fast', 'sample' => '5-istin-o-poste-daniila'],
];

function pcnl_ensure_categories() {
	foreach (PCNL_SECTIONS as $sec => $d) {
		foreach (['ru' => 'Сайт RU — ' . $d['ru'], 'en' => 'Site EN — ' . $d['en']] as $lang => $name) {
			$slug = "pc-$lang-$sec";
			if (!term_exists($slug, 'category')) {
				wp_insert_term($name, 'category', ['slug' => $slug, 'description' => 'Записи этой рубрики показываются в новом виде сайта']);
			}
		}
	}
}
add_action('admin_init', 'pcnl_ensure_categories');

function pcnl_activate() {
	pcnl_ensure_categories();
	pcnl_purge_cache();
}

// Язык и раздел записи по её рубрике: [lang, sec] или null.
function pcnl_post_place($post) {
	foreach ((array) wp_get_post_categories($post->ID, ['fields' => 'slugs']) as $slug) {
		if (preg_match('#^pc-(ru|en)-(molitva|resursy|post-daniila)$#', $slug, $m)) {
			return [$m[1], $m[2]];
		}
	}
	return null;
}

function pcnl_post_url($post, $lang) {
	return home_url(($lang === 'ru' ? '/ru/' : '/') . $post->post_name . '/');
}

function pcnl_section_posts($lang, $sec) {
	return get_posts([
		'post_type' => 'post',
		'post_status' => 'publish',
		'category_name' => "pc-$lang-$sec",
		'posts_per_page' => 100,
		'orderby' => 'date',
		'order' => 'ASC',
		'suppress_filters' => false,
	]);
}

function pcnl_short($post) {
	$text = $post->post_excerpt !== '' ? $post->post_excerpt : strip_shortcodes(wp_strip_all_tags($post->post_content));
	$text = trim(preg_replace('/\s+/u', ' ', html_entity_decode($text, ENT_QUOTES, 'UTF-8')));
	if (mb_strlen($text) > 150) {
		$text = mb_substr($text, 0, 150);
		$text = rtrim(preg_replace('/\s+\S*$/u', '', $text), ',.;:—-') . '…';
	}
	return $text;
}

function pcnl_add_posts_to_list($html, $lang, $sec) {
	$start = strpos($html, '<ol class="list">');
	if ($start === false) {
		return $html;
	}
	$posts = pcnl_section_posts($lang, $sec);
	if (!$posts) {
		return $html;
	}
	$end = strpos($html, '</ol>', $start);
	$n = substr_count(substr($html, $start, $end - $start), '<li>');
	preg_match('#<svg class="ic arrow".*?</svg>#s', $html, $arrow);
	$rows = '';
	foreach ($posts as $post) {
		$n++;
		$rows .= sprintf(
			'<li><a href="%s"><i>%02d</i><span><strong>%s</strong><span>%s</span></span>%s</a></li>',
			esc_url(pcnl_post_url($post, $lang)), $n, esc_html(get_the_title($post)), esc_html(pcnl_short($post)), $arrow[0] ?? ''
		);
	}
	return substr($html, 0, $end) . $rows . substr($html, $end);
}

function pcnl_find_post($slug) {
	if ($slug === '' || strpos($slug, '/') !== false) {
		return null;
	}
	$found = get_posts(['name' => $slug, 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1]);
	return $found ? $found[0] : null;
}

function pcnl_render_post($post, $lang, $sec) {
	$sample = PCNL_SECTIONS[$sec]['sample'];
	$file = PCNL_DIR . ($lang === 'ru' ? '/ru/' : '/') . $sample . '/index.html';
	if (!is_file($file)) {
		return false;
	}
	$html = file_get_contents($file);
	$a = strpos($html, '<article class="wrap article">');
	$b = $a === false ? false : strpos($html, '</article>', $a);
	if ($a === false || $b === false) {
		return false;
	}
	$article = substr($html, $a, $b - $a);
	preg_match('#<a class="back".*?</a>#s', $article, $back);
	preg_match('#<a class="btn btn-paper".*?</a>#s', $article, $back2);
	$title = get_the_title($post);
	$content = function_exists('do_blocks') ? do_blocks($post->post_content) : $post->post_content;
	$body = do_shortcode(wpautop($content));
	if (has_post_thumbnail($post)) {
		$body = '<p>' . get_the_post_thumbnail($post, 'large', ['style' => 'width:100%;height:auto;border-radius:12px']) . '</p>' . $body;
	}
	$new = "<article class=\"wrap article\">\n  " . ($back[0] ?? '') . "\n  <h1>" . esc_html($title) . "</h1>\n  <div class=\"prose\">" . $body . "</div>\n  " . ($back2[0] ?? '') . "\n";
	$html = substr($html, 0, $a) . $new . substr($html, $b);
	$html = preg_replace('#<title>.*?</title>#s', '<title>' . esc_html($title) . ' | Prayer Call</title>', $html, 1);
	$html = preg_replace('#<meta name="description" content="[^"]*">#', '<meta name="description" content="' . esc_attr(pcnl_short($post)) . '">', $html, 1);
	$html = preg_replace('#<link rel="alternate" hreflang="[^"]*" href="[^"]*">\s*#', '', $html);
	// переключатель языка ведёт в тот же раздел на другом языке
	$html = str_replace('/' . $sample . '/', '/' . $sec . '/', $html);
	return $html;
}

function pcnl_serve_post() {
	$rel = pcnl_rel_path();
	if ($rel === null || $rel === '') {
		return;
	}
	$lang = 'en';
	$slug = $rel;
	if (strpos($rel, 'ru/') === 0) {
		$lang = 'ru';
		$slug = substr($rel, 3);
	}
	$post = pcnl_find_post($slug);
	$place = $post ? pcnl_post_place($post) : null;
	if (!$place) {
		return;
	}
	$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
	if ($place[0] !== $lang || substr($path, -1) !== '/') {
		wp_redirect(pcnl_post_url($post, $place[0]), 301);
		exit;
	}
	$html = pcnl_render_post($post, $lang, $place[1]);
	if ($html !== false) {
		pcnl_output($html);
	}
}
add_action('wp_loaded', 'pcnl_serve_post', -999);

// «Просмотреть запись» в админке ведёт на адрес в новом виде
add_filter('post_link', function ($url, $post) {
	if ($post->post_status !== 'publish') {
		return $url;
	}
	$place = pcnl_post_place($post);
	return $place ? pcnl_post_url($post, $place[0]) : $url;
}, 10, 2);
